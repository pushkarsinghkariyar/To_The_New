package com.ttnd.linksharing.vo

class RatingInfoVO {
    Integer totalVotes
    Integer averageScore
    Integer totalScore
}
