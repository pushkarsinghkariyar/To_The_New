package com.ttnd.linksharing.vo

class UserVO {
    Long id
    String email
    String username
    String password
    String firstName
    String lastName
    Boolean active
}
