package com.ttnd.linksharing

class DefaultPassword {
    public static final DEFAULT_PASSWORD = "lsdefault"
}
