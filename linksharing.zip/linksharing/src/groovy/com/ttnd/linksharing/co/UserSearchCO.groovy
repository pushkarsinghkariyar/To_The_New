package com.ttnd.linksharing.co

class UserSearchCO extends SearchCO {
    Boolean active

}
