package com.ttnd.linksharing.co

class SearchCO {
    String q
    Integer max
    Integer offset
    String order
    String sort
}
