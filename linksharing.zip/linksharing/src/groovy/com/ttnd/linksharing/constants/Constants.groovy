package com.ttnd.linksharing.constants

class Constants {
    static final String DOCUMENT_CONTENT_TYPE = 'application/pdf'
}
