package com.ttnd.linksharing

import spock.lang.Specification

class ApplicationFilterFiltersSpec extends Specification {

}
