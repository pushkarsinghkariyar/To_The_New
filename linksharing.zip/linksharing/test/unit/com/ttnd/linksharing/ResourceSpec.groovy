package com.ttnd.linksharing

import grails.test.mixin.TestFor
import spock.lang.Specification

@TestFor(Resource)
class ResourceSpec extends Specification {

}
