map = ["name":"nitin"]

m{
first = "Hello"
second = "Groovy"
}

println "ext config loaded"
